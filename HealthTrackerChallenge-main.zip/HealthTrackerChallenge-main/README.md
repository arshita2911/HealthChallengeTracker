# HealthChallengeTracker

This repo is the solution to the Fyle's [frontend assignment](https://fyleuniverse.notion.site/Frontend-Development-Challenge-091d1fad48d94c6a9de0c02465cc640a#bfeceebf375d44e29b4e53be4f9b5792).